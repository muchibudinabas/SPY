<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class ExampleTestt extends TestCaset
{
    /**
     * A basic functional test example.
     *
     * @return void
     */
    // public function testBasicExample()
    // {
    //     $response = $this->call('GET','tes');
    //     // $this->see('testing', 'h1');
    //     // $this->assertEquals('testing', $response->getContent());
    //     $this->assertTrue(strpos($response->getContent(), 'testingfdgdf') !==true);

    // }

    // protected function see($text, $element = 'body') {
    //     $crowler = $this->client->getCrowles();
    //     $found = $crowler->filter("{$element}:contains('{$text}')");

    //     $this->assertGreaterThan(0, count($found), "Expected to see {$text} within the view");
    // } 
}
