<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class ApprovePendaftaranTest extends TestCasesxcasc
{
    /**
     * A basic test example.
     *
     * @return void
     */
   //  public function testApprovePendaftaranSuccess()
   //  {
   //      // $this->assertTrue(true);
   //      $this->visit('/')
			// ->type('SistemInformasi', 'username')
			// ->type('SistemInformasi2016', 'password')
			// ->press('Log In')
			// ->seePageIs('/home')
			// ->visit('/approve')
			// // ->press('open-modal')
			// ->get('/approve/edit/141414141414')
			// ->post('/approve/approvePendaftaran/141414141414')
			// // ->press('approve2')
			//  // ->post('/approve/approvePendaftaran/141414141414')
            
   //          ->seeJson(['sfsfsf'=>'dfsfsf'])


			// // ->see('Apakah anda yakin akan mengapprove data')


			// ;
   //  }
}
