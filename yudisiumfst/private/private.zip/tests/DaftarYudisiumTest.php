<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;


class DaftarYudisiumTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
    // public function testExample()
    // {
    //     // $this->assertTrue(true);
    // 	echo "strisfsfng";

    //     $this->visit('/')
    //      ->type('Kemahasiswaan', 'username')
    //      ->type('Kemahasiswaan2016', 'password')
    //      ->press('Log In')
    //      ->see('Kemahasiswaan');
    //      // ->seePageIs('/ssxsx');

    // }

    public function testDaftarYudisiumSuccess()
    {
        $this->visit('/')
			->type('141414141414', 'nim')
			->type('Budi', 'namamahasiswa')
			->select('7', 'prodi')
			->type('11-08-2012', 'tglterdaftar')
			->type('3.44', 'ipk')
			->type('567', 'elpt')
			->type('Rekayasa Sistem Informasi', 'bidangilmu')
			->type('Sistem pendaftaran yusidium', 'judulpenelitihan')
			->type('Pak Taufiq', 'dosenpembimbing1')
			->type('Bu Endah', 'dosenpembimbing2')
			->type('Surabaya', 'tempatlahir')
			->type('11-08-2012', 'tanggallahir')
			->select('1IS', 'agama')
			->select('1', 'jeniskelamin')
			->type('Surabaya', 'alamat')
			->type('085733543033', 'telpon')
			->type('Andi', 'namaortu')
			->type('Surabaya', 'alamatortu')
			->type('085733543033', 'telponortu')
			->press('Daftar')
			->see('Pendaftaran Yudisium Berhasil!');

    }

   //  public function testPernahDaftarYudisium()
   //  {
   //      $this->visit('/')
			// ->type('081211631057', 'nim')
			// ->type('Abas', 'namamahasiswa')
			// ->select('2', 'prodi')
			// ->type('11-08-2012', 'tglterdaftar')
			// ->type('3.44', 'ipk')
			// ->type('567', 'elpt')
			// ->type('Rekayasa Sistem Informasi', 'bidangilmu')
			// ->type('Sistem pendaftaran yusidium', 'judulpenelitihan')
			// ->type('Pak Taufiq', 'dosenpembimbing1')
			// ->type('Bu Endah', 'dosenpembimbing2')
			// ->type('Surabaya', 'tempatlahir')
			// ->type('11-08-2012', 'tanggallahir')
			// ->select('3', 'agama')
			// ->select('1', 'jeniskelamin')
			// ->type('Surabaya', 'alamat')
			// ->type('085733543033', 'telpon')
			// ->type('Andi', 'namaortu')
			// ->type('Surabaya', 'alamatortu')
			// ->type('085733543033', 'telponortu')
			// ->select('1', 'fy')
			// ->attach(base_path().'/uploads/files/(a)141414141414.pdf', 'fileyudisium')
			// ->press('Daftar')
			// ->see('NIM anda sudah pernah mendaftar yudisium, silahkan hubungi TU Prodi');
    
   //  }

}
