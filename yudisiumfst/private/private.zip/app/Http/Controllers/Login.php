<?php
namespace App\Http\Controllers;
use Redirect;
use App\Gettabeluser;
use App\TabelUserAccount;
use App\TabelWisudawan;
use App\TabelPegawai;
use App\TabelJabatan;
use App\TabelUnit;




use App\Http\Controllers\belajarcontroler;
use App\User;
use Illuminate\Contracts\Mail\MailQueue;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Contracts\Auth\Guard;
use View;
use Input;
use Hash;
use DB;
use Session;
use Auth;
use Mail;
use Validator;
use Flash;
use App\Quotation;
use Carbon\Carbon;
use Response;
class Login extends BaseController {

    public function login() {
        $input = Input::all();
        $user = Input::get('username');
        $pass = Input::get('password');

        $data = TabelUserAccount::all()->where('USERNAME', ($user))->where('PASSWORD', md5($pass))->where('AKTIVASI','1');

        $datanim = TabelWisudawan::all()->where('NIM', ($user))->where('PASSWORD_TEMP', ($pass))->where('VERIFIKASI_AK','0');

        $nimexpired = TabelWisudawan::all()->where('NIM', ($user))->where('PASSWORD_TEMP', ($pass))->where('VERIFIKASI_AK','1');

        if ($data->count() > 0) {
            foreach ($data as $data1) {
                Session::put('username', $user);
                Session::put('nip', $data1->NIP);
                Session::put('image', $data1->IMAGE);
                Session::put('access', ("true"));
                return Redirect::to('/home')->with('warning', 'Login Sukses');
                return 'sukses';
            }
        } else if ($datanim->count() > 0) {
            foreach ($datanim as $data1) {
                Session::put('nim', $user);
                Session::put('access', ("true"));
                
                return Redirect::to('/dashboard')->with('warning', 'Login Sukses');

            }
        } else if ($nimexpired->count() > 0) {
            return Redirect::to("/#login")->withInput()->with('warning', 'Anda sudah menjadi wisudawan, <br><b>Akun expired!</b>');
        } else {
            return Redirect::to("/#login")->withInput()->with('warning', 'Username or Password Incorrect');
        }

    }

    public function home() {

        if (Session::has('access')) {

            $nip = Session::get('nip');
            
            $data = TabelPegawai::where('NIP',$nip)->get();
            foreach ($data as $data1) {
                // $idjabatan = $data1->ID_JABATAN;
                // $idunit = $data1->ID_UNIT;
                Session::put('jabatan', $data1->ID_JABATAN);
                Session::put('idunit', $data1->ID_UNIT);
            }

            $idjabatan = Session::get('jabatan');
            $idunit = Session::get('idunit');

            if ($idjabatan == "1") {

                $data2  = DB::table('anggota_ruangbaca')
                    ->select(DB::raw('count(*) as nim_count, NIM_ANGGOTA'))
                    ->get();

                $data3  = DB::table('detail_pinjam_buku')
                    ->select(DB::raw('count(*) as pinjam_count, STATUS_PINJAM'))
                    ->where('STATUS_PINJAM', '=', 0)
                    ->get();

                $profile = TabelPegawai::where('NIP','=',$nip)
                        ->get();

                return view('ruangbaca.home', compact('data2', 'data3', 'profile'));

            } else if ($idjabatan == "2") {
                // return 'prodi';
                    $data2  = DB::table('wisudawan')
                    ->select(DB::raw('count(*) as verifikasi_count, VERIFIKASI'))
                    ->where('VERIFIKASI', '=', 0)
                    ->where('ID_UNIT', '=', $idunit)
                    ->whereNotNull('NAMA_ORTU')
                    ->get();

                    $dataprocess  = DB::table('wisudawan')
                    ->select(DB::raw('count(*) as verifikasi_count, VERIFIKASI'))
                    ->where('VERIFIKASI', '=', 1)
                    ->where('VERIFIKASI_AK', '=', 0)
                    ->where('ID_UNIT', '=', $idunit)
                    ->whereNotNull('NAMA_ORTU')
                    ->get();

                    $alumni  = DB::table('wisudawan')
                    ->select(DB::raw('count(*) as verifikasi_count, VERIFIKASI_AK'))
                    ->where('VERIFIKASI_AK', '=', 1)
                    ->where('ID_UNIT', '=', $idunit)
                    ->get();
                        
                    $profile = TabelPegawai::where('NIP','=',$nip)
                        ->get();

                    return View::make('prodi.home', compact('data2', 'dataprocess', 'alumni', 'profile'));

            } else if ($idjabatan == "3") {
                // return 'kemahasiswaan';  

                $skp  = DB::table('wisudawan')
                ->select(DB::raw('count(*) as verifikasi_count, NIM'))
                ->whereNull('SKP')
                ->where('VERIFIKASI_AK', '=', 0)
                ->get();

                $data2  = DB::table('wisudawan')
                ->select(DB::raw('count(*) as verifikasi_count, NIM'))
                ->whereNotNull('SKP')
                ->where('VERIFIKASI_AK', '=', 0)
                ->get();

                $alumni  = DB::table('wisudawan')
                    ->select(DB::raw('count(*) as verifikasi_count, VERIFIKASI_AK'))
                    // ->whereNotNull('SKP')
                    ->where('VERIFIKASI_AK', '=', 1)
                    ->get();

                $profile = TabelPegawai::where('NIP','=',$nip)
                        ->get();


                return view('kemahasiswaan.home', compact('skp', 'data2', 'alumni', 'profile'));
         
            } else if ($idjabatan == "4") {
                // return 'akademik';

                $data2  = DB::table('wisudawan')
                ->select(DB::raw('count(*) as verifikasi_count, VERIFIKASI'))
                ->where('VERIFIKASI', '=', 1)
                ->where('VERIFIKASI_AK', '=', 0)
                ->get();

                $user  = DB::table('user_account')
                    ->select(DB::raw('count(*) as verifikasi_count, USERNAME'))
                    ->get();

                $alumni  = DB::table('wisudawan')
                    ->select(DB::raw('count(*) as verifikasi_count, VERIFIKASI_AK'))
                    ->where('VERIFIKASI_AK', '=', 1)
                    ->get();
                    
                $profile = TabelPegawai::where('NIP','=',$nip)
                    ->get();
                return view('akademik.home', compact('data2', 'user', 'alumni', 'profile'));
            } 
       
        } else {
            return redirect('/logout');
        }
    }

    public function logout()
    {
        Session::flush();
        return redirect('');
    }
}
 