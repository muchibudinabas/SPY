@include:Creating a new file|simple
@include:Exporting|export
@include:NewExcelFile injections|injection
@include:Store to server|store
@include:Creating Sheets|sheets
@include:Creatings Sheets From array|array
@include:Row manipulation|rows
@include:Cell manipulation|cells
@include:Sheet styling|sheet-styling
@include:Freeze rows|freeze
@include:Auto filter|autofilter
@include:Cell sizing|sizing
@include:Auto size|autosize
@include:Column merging|merge
@include:Column formatting|format
@include:PHPExcel methods|call