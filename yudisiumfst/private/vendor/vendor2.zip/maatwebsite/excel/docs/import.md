@include:Importing a file|basics
@include:ExcelFile injections|injection
@include:Handling results|results
@include:Selecting sheets and columns|select
@include:Dates|dates
@include:Calculation|calculation
@include:Custom formatting values|formatting
@include:Caching and cell caching|cache
@include:Chunk importing|chunk
@include:Batch import|batch
@include:Import by config|config
@include:Edit existing files|edit
@include:Converting|convert
@include:Extra|extra