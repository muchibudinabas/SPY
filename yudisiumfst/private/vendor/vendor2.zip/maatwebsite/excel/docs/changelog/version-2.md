# Version 2

### 2.0.4
- PHPExcel 1.8.1 compatibility
- Clean-up ServiceProvider

### 2.0.3
- Fix usage of sheet callback when modifying an existing file
- Modifying existing files improvements (support style overriding)
- Add text-indent support to HtmlReader
- Add simple sheet password protection
- Add support for exporting multiple pdf pages
- Add inline cell formatting to blade

### 2.0.2
- Fix issue with different start row in chunk filter

### 2.0.1
- Custom value binders
- Html reader update

### 2.0.0
- Laravel 5 release
